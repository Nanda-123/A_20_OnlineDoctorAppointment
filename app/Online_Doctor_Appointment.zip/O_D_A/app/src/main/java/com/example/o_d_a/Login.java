package com.example.o_d_a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;


public class Login extends AppCompatActivity {
    public Button button;
    EditText emailEtv,passwordEtv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailEtv = findViewById(R.id.emailAddressEtv1);
        passwordEtv = findViewById(R.id.passwordEtv1);
        button = findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View v){
                String email=emailEtv.getText().toString();
                String password=passwordEtv.getText().toString();

                boolean check= validinfo(email,password);

                if(check==true){
                    Toast.makeText(getApplicationContext(),"Data is Valid",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Sorry Check Information Once",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public Boolean validinfo(String email, String password){
        if (email.length() == 0) {
            emailEtv.requestFocus();
            emailEtv.setError("Field Cannot Be Empty");
            return false;
        } else if (!email.matches("[a-zA-Z0-9,_-]+@[a-z]+\\.+[a-z]+")) {
            emailEtv.requestFocus();
            emailEtv.setError("Enter Valid Email");
            return false;
        } else if (password.length()<=5){
            passwordEtv.requestFocus();
            passwordEtv.setError("Minimum 6 characters are required");
            return false;
        }else {
            return true;
        }
    }
    }
