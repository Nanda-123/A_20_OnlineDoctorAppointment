package com.example.o_d_a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class Login1 extends AppCompatActivity {
    public Button button;
    public Button button1;
    EditText emailAddressEtv,passwordEtv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login1);

        emailAddressEtv = findViewById(R.id.emailAddressEtv);
        passwordEtv1 = findViewById(R.id.passwordEtv1);

        button = findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View v){
                String email=emailAddressEtv.getText().toString();
                String password=passwordEtv1.getText().toString();

                boolean check= validInfo(email,password);

                if(check==true){
                    Toast.makeText(getApplicationContext(),"Data is Valid",Toast.LENGTH_SHORT).show();
                    openHome();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Sorry Check Information Once",Toast.LENGTH_SHORT).show();
                }
            }
        });

        button1 = findViewById(R.id.button3);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View a) {
                String email1 = emailAddressEtv.getText().toString();
                String password1 = passwordEtv1.getText().toString();

                boolean check= emptyInfo(email1,password1);

                if(check==true) {
                    openSignup();
                }
                //button1.setOnClickListener(b -> openSignup());
            }
        });
    }
    public Boolean validInfo(String email, String password){
        if (email.length() == 0) {
            emailAddressEtv.requestFocus();
            emailAddressEtv.setError("Field Cannot Be Empty");
            return false;
        } else if (!email.matches("[a-zA-Z0-9,_-]+@[a-z]+\\.+[a-z]+")) {
            emailAddressEtv.requestFocus();
            emailAddressEtv.setError("Enter Valid Email");
            return false;
        } else if (password.length()<=5){
            passwordEtv1.requestFocus();
            passwordEtv1.setError("Minimum 6 characters are required");
            return false;
        }else {
            return true;
        }
    }
    public void openHome(){
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }

    public Boolean emptyInfo(String email1,String password1){
        if (!(email1.length() == 0)) {
            return false;
        } else if(!(password1.length()<=0)){
            return false;
        } else{
            return true;
        }
    }

    public void openSignup(){
        Intent intent = new Intent(this, Signup.class);
        startActivity(intent);
    }
}









