package com.example.o_d_a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class Signup extends AppCompatActivity {
    public Button button;
    EditText nameEtv, emailEtv, passwordEtv, addressEtv, ageEtv, numberEtv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        nameEtv=findViewById(R.id.nameetv);
        emailEtv=findViewById(R.id.emailetv);
        passwordEtv=findViewById(R.id.passwordetv);
        addressEtv=findViewById(R.id.addressetv);
        ageEtv=findViewById(R.id.agetv);
        numberEtv=findViewById(R.id.numberetv);

        button = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View v){
                String name=nameEtv.getText().toString();
                String email=emailEtv.getText().toString();
                String password=passwordEtv.getText().toString();
                String address=addressEtv.getText().toString();
                String age=ageEtv.getText().toString();
                String number=numberEtv.getText().toString();

                boolean check= validateInfo(name,email,password,address,age,number);

                if(check==true){
                    Toast.makeText(getApplicationContext(),"Data is Valid",Toast.LENGTH_SHORT).show();
                    openHome();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Sorry Check Information Once",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    public Boolean validateInfo(String name, String email, String password, String address, String age, String number) {
        if (name.length() == 0) {
            nameEtv.requestFocus();
            nameEtv.setError("Field Cannot Be Empty");
            return false;
        } else if (!name.matches("[a-zA-Z]+")) {
            nameEtv.requestFocus();
            nameEtv.setError("Only Alphabets are Allowed");
            return false;
        } else if (email.length() == 0) {
            emailEtv.requestFocus();
            emailEtv.setError("Field Cannot Be Empty");
            return false;
        } else if (!email.matches("[a-zA-Z0-9,_-]+@[a-z]+\\.+[a-z]+")) {
            emailEtv.requestFocus();
            emailEtv.setError("Enter Valid Email");
            return false;
        } else if (password.length()<=5){
            passwordEtv.requestFocus();
            passwordEtv.setError("Minimum 6 characters are required");
            return false;
        } else if(address.length() == 0) {
            addressEtv.requestFocus();
            addressEtv.setError("Field Cannot Be Empty");
            return false;
        } else if (!address.matches("[a-zA-Z]+")) {
            addressEtv.requestFocus();
            addressEtv.setError("Only Alphabets are Allowed");
            return false;
        }else if (age.length() == 0) {
            ageEtv.requestFocus();
            ageEtv.setError("Field Cannot Be Empty");
            return false;
        } else if(!age.matches("[0-9]{2}$")){
            ageEtv.requestFocus();
            ageEtv.setError("atMost 2 digits are allowed");
            return false;
        }  if (number.length() == 0) {
            numberEtv.requestFocus();
            numberEtv.setError("Field Cannot Be Empty");
            return false;
        } else if(!number.matches("[0-9]{10}$")){
            numberEtv.requestFocus();
            numberEtv.setError("Fill 10 Digit number");
            return false;
        }
        else {
            return true;
        }
    }

    public void openHome() {
        Intent intent = new Intent(this, Login1.class);
        startActivity(intent);
    }
}

